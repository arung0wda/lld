// Device class to connect USB A cable

// New system

class USB_C_Device {
  plugIn() {
    return "USB C device connected";
  }
}

module.exports = USB_C_Device;
